install.packages("interactions")
library(interactions)
my_data <- read.csv(file = "Ch16d.csv")
reg <- lm (math ~ agg * att, data = my_data)
summary(reg)
mod <- johnson_neyman(model = reg, pred = agg, modx = att,
                      mod.range = c(-1,6))
mod
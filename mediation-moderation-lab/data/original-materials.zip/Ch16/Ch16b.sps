﻿*Significance interval of Johnson-Neyman technique (group=2) by Potthoff (1964).
SET Format=F7.3.
DATA LIST FREE /Fcrit r SSe n1 m1 SS1 a1 b1 n2 m2 SS2 a2 b2.
BEGIN DATA
4.113 1 11.0376 20 61.35 6094.55 4.269 .0967 20 58.65 6302.55 3.857 -.106
END DATA .
LIST VARIABLES =Fcrit r SSe n1 m1 SS1 a1 b1 n2 m2 SS2 a2 b2 /FORMAT=NUMBERED.
*採R估計法執行此指令.
COMPUTE Fcv=Fcrit.           
*採R估計法執行此指令.
*COMPUTE Fcv=(r+1)*Fcrit.
COMPUTE F=(Fcv/(n1+n2-4))*SSe.
COMPUTE INT=(a1-a2)/(b2-b1) .
COMPUTE A=(-1)*F*((1/SS1)+(1/SS2))+(b1-b2)**2 .
COMPUTE B=F*((m1/SS1)+(m2/SS2))+((a1-a2)*(b1-b2)).
COMPUTE C=(-1)*F*(((n1+n2)/(n1*n2))+((m1**2)/SS1)+((m2**2)/SS2))+(a1-a2)**2 .
COMPUTE XL=((-1)*B - sqrt((B**2)-A*C)) /A .
COMPUTE XU=((-1)*B +sqrt((B**2)-A*C))/A .
LIST VARIBABLES= INT A B C XL XU.
EXECUTE.

install.packages("interactions")
library(interactions)
my_data <- read.csv(file = "Ch16b.csv")
M1 <- lm (Y ~ X * D, data = my_data)
summary(M1)
mod <- johnson_neyman(model = M1, pred = D, modx = X,
                      mod.range = c(20,100))
mod

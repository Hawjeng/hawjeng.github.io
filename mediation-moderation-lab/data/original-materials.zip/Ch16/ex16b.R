install.packages("interactions")
library(interactions)
my_data <- read.csv(file = "ex16b.csv")
M1 <- lm (Y ~ X * Z, data = my_data)
summary(M1)
mod <- johnson_neyman(model = M1, pred = Z, modx = X,
                      mod.range = c(2,12))
mod

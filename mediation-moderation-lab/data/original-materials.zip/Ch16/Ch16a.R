install.packages("interactions")
library(interactions)
my_data <- read.csv(file = "ex16a.csv")
M1 <- lm (Y ~ X1 * X2, data = my_data)
summary(M1)
mod <- johnson_neyman(model = M1, pred = X1, modx = X2,
                      mod.range = c(-5,25))
mod
